package com.Tarefa_2.tarefa2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarefa2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
