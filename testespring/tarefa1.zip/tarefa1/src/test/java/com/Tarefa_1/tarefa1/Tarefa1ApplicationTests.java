package com.Tarefa_1.tarefa1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarefa1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
