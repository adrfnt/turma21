package com.Tarefa_1.tarefa1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tarefa1Application {

	public static void main(String[] args) {
		SpringApplication.run(Tarefa1Application.class, args);
	}

}
