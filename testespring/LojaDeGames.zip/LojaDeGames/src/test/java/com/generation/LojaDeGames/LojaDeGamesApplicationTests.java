package com.generation.LojaDeGames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaDeGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
